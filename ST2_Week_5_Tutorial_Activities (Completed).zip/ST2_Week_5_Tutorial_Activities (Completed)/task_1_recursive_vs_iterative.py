import time

# ---------------- RECURSIVE ---------------- #

def fibonacci_rec(n):
    if n <= 1:
        return n
    return fibonacci_rec(n-1) + fibonacci_rec(n-2)

def factorial_rec(n):
    if n == 0 or n == 1:
        return 1
    return n * factorial_rec(n-1)

def countdown_rec(n):
    if n == 0:
        return
    countdown_rec(n-1)


# ---------------- ITERATIVE ---------------- #

def fibonacci_iter(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

def factorial_iter(n):
    result = 1
    for i in range(1, n+1):
        result *= i
    return result

def countdown_iter(n):
    while n > 0:
        n -= 1


# ---------------- TIMING FUNCTION ---------------- #

def measure_time(func, n, repeat=10000):
    start = time.perf_counter()
    for _ in range(repeat):
        func(n)
    end = time.perf_counter()
    return (end - start) / repeat


# ---------------- TEST CASES ---------------- #

n_small = 5
n_medium = 10
n_large = 20 


print("=== Fibonacci ===")
# Format to 10 decimal places to avoid scientific notation
print(f"Recursive: {measure_time(fibonacci_rec, n_large):.10f}")
print(f"Iterative: {measure_time(fibonacci_iter, n_large):.10f}")

print("\n=== Factorial ===")
print(f"Recursive: {measure_time(factorial_rec, n_medium):.10f}")
print(f"Iterative: {measure_time(factorial_iter, n_medium):.10f}")

print("\n=== Countdown ===")
print(f"Recursive: {measure_time(countdown_rec, 500):.10f}")
print(f"Iterative: {measure_time(countdown_iter, 500):.10f}")