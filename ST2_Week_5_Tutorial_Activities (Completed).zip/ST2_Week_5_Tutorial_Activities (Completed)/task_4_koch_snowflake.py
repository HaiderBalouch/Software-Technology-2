# koch_snowflake.py
from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width=self.width, height=self.height, bg="white")
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, width=5, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Snowflake", command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")
        order = int(self.order.get())
        
        # Define the three vertices of the initial equilateral triangle
        p1 = [self.width / 2, 20]
        p2 = [20, self.height - 100]
        p3 = [self.width - 20, self.height - 100]

        # Draw the three sides of the snowflake recursively
        self.draw_koch_edge(order, p1, p2)
        self.draw_koch_edge(order, p2, p3)
        self.draw_koch_edge(order, p3, p1)

    def draw_koch_edge(self, order, p1, p5):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p5[0], p5[1], tags="line")
        else:
            dx = p5[0] - p1[0]
            dy = p5[1] - p1[1]

            # Point 2: 1/3 of the way
            p2 = [p1[0] + dx / 3, p1[1] + dy / 3]

            # Point 4: 2/3 of the way
            p4 = [p1[0] + 2 * dx / 3, p1[1] + 2 * dy / 3]

            # Point 3: The tip of the triangle
            # Using rotation matrix for 60 degrees
            p3 = [0, 0]
            p3[0] = (p2[0] + p4[0]) / 2 + (math.sqrt(3) * (p2[1] - p4[1])) / 2
            p3[1] = (p2[1] + p4[1]) / 2 + (math.sqrt(3) * (p4[0] - p2[0])) / 2

            # Recursively draw the 4 new segments
            self.draw_koch_edge(order - 1, p1, p2)
            self.draw_koch_edge(order - 1, p2, p3)
            self.draw_koch_edge(order - 1, p3, p4)
            self.draw_koch_edge(order - 1, p4, p5)

KochSnowflake()