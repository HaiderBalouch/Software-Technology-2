import random
import timeit

# --- ALGORITHM DEFINITIONS ---

def merge_sort(array):
    if len(array) <= 1:
        return array
    
    mid = len(array) // 2
    left = merge_sort(array[:mid])
    right = merge_sort(array[mid:])

    return merge(left, right)

def merge(left, right):
    merged = []
    l_ptr = r_ptr = 0

    while l_ptr < len(left) and r_ptr < len(right):
        if left[l_ptr] <= right[r_ptr]:
            merged.append(left[l_ptr])
            l_ptr += 1
        else:
            merged.append(right[r_ptr])
            r_ptr += 1
    
    merged.extend(left[l_ptr:])
    merged.extend(right[r_ptr:])
    return merged

def insertion_sort(arr):
    # We copy the array to avoid sorting the original reference during benchmarks
    data = arr[:]
    for i in range(1, len(data)):
        key = data[i]
        j = i - 1
        while j >= 0 and key < data[j]:
            data[j + 1] = data[j]
            j -= 1
        data[j + 1] = key
    return data

# --- BENCHMARKING FUNCTION ---

def run_benchmarks(sizes):
    print(f"{'Size':<10} | {'Merge Sort (s)':<18} | {'Insertion Sort (s)':<18}")
    print("-" * 50)
    
    for size in sizes:
        test_data = [random.randint(1, 10000) for _ in range(size)]
        
        # Benchmark Merge Sort
        m_time = timeit.timeit(lambda: merge_sort(test_data), number=10)
        
        # Benchmark Insertion Sort
        i_time = timeit.timeit(lambda: insertion_sort(test_data), number=10)
        
        print(f"{size:<10} | {m_time:<18.6f} | {i_time:<18.6f}")

# (1) Test for different data sizes
# (2) & (3) Benchmark and compare
data_sizes = [100, 500, 1000, 2000]
run_benchmarks(data_sizes)