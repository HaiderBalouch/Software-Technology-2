# TowerOfHanoi_Modified.py

# Global variable to track the number of moves
count = 0

def main():
    global count
    n = int(input("Enter number of disks: "))
    
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    
    print(f"\nThe number of moves is {count}")

def moveDisks(n, fromTower, toTower, auxTower):
    global count
    if n == 1:
        # Increment move count
        count += 1
        print(f"Move disk {n} from {fromTower} to {toTower}")
    else:
        # Step 1: Move n-1 disks from source to auxiliary
        moveDisks(n - 1, fromTower, auxTower, toTower)
        
        # Step 2: Move the largest disk to the target
        count += 1
        print(f"Move disk {n} from {fromTower} to {toTower}")
        
        # Step 3: Move the n-1 disks from auxiliary to target
        moveDisks(n - 1, auxTower, toTower, fromTower)

if __name__ == "__main__":
    main()