from tkinter import *

class SierpinskiTriangle:
    def __init__(self):
        window = Tk()
        window.title("Sierpinski Triangle")

        # Canvas Setup
        self.width = 400  # Increased size for better visibility
        self.height = 400
        self.canvas = Canvas(window, width=self.width, height=self.height, bg="white")
        self.canvas.pack(pady=10)

        # UI Controls
        frame1 = Frame(window)
        frame1.pack(padx=10, pady=10)

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        self.entry = Entry(frame1, textvariable=self.order, width=5, justify=RIGHT)
        self.entry.pack(side=LEFT, padx=5)
        
        Button(frame1, text="Display Sierpinski Triangle", 
               command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")
        
        # Basic validation to handle empty or non-integer input
        try:
            order_val = int(self.order.get())
        except ValueError:
            return

        # Define the three vertices of the outermost triangle
        p1 = [self.width / 2, 20]
        p2 = [20, self.height - 20]
        p3 = [self.width - 20, self.height - 20]
        
        self.display_triangles(order_val, p1, p2, p3)

    def display_triangles(self, order, p1, p2, p3):
        if order == 0:
            # Base Case: Draw the triangle lines
            self.draw_line(p1, p2)
            self.draw_line(p2, p3)
            self.draw_line(p3, p1)
        else:
            # Recursive Step: Get midpoints of each side
            p12 = self.midpoint(p1, p2)
            p23 = self.midpoint(p2, p3)
            p31 = self.midpoint(p3, p1)

            # Draw the three smaller sub-triangles recursively
            self.display_triangles(order - 1, p1, p12, p31)
            self.display_triangles(order - 1, p12, p2, p23)
            self.display_triangles(order - 1, p31, p23, p3)

    def draw_line(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line", fill="blue")

    def midpoint(self, p1, p2):
        """Calculates the center point between two vertices."""
        return [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]

# Run the application
if __name__ == "__main__":
    SierpinskiTriangle()