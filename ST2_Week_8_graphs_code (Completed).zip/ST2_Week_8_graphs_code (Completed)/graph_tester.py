#graph_tester.py
from graph import Graph

# === Task 1: Basic undirected graph tests ===
print("--- Undirected Graph Tests ---")
g = Graph()
# Requirement: Add vertices A, B, C, D
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D') # Added edge to include D
g.add_edge('D', 'A') # Added edge to include D

g.print_graph()
print()


# === Task 1: Directed graph tests ===
print("--- Directed Graph Tests ---")
g_dir = Graph(directed=True)
for v in ['A', 'B', 'C', 'D']:
    g_dir.add_vertex(v)

g_dir.add_edge('A', 'B')
g_dir.add_edge('B', 'C')
g_dir.add_edge('C', 'D') # Added edge to include D

g_dir.print_graph()
print()

# === Task 1 & 5: Weighted graph tests ===
print("--- Weighted Directed Graph Tests ---")
g_weight = Graph(weighted=True, directed=True)
for v in ['A', 'B', 'C', 'D']:
    g_weight.add_vertex(v)

g_weight.add_edge('A', 'B', 15)
g_weight.add_edge('B', 'C', 34)
g_weight.add_edge('C', 'D', 20) # Added weighted edge to D

g_weight.print_graph()


# === Task 1: Removal tests ===
print()
print("--- Removal Test ---")
removal_test = Graph()
for v in ['A', 'B', 'C', 'D']:
    removal_test.add_vertex(v)

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
removal_test.add_edge('C', 'D')

print("Initial Graph with D:")
removal_test.print_graph()

print("Removing edge A-B:")
removal_test.remove_edge('A', 'B')
removal_test.print_graph()

print("Removing vertex C:")
removal_test.remove_vertex('C')
removal_test.print_graph()
print()


# === Task 2: BFS on the graph ===
print("BFS starting from vertex 'A':")
# Using the first undirected graph 'g' which now contains D
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)


# === Task 3: DFS on the graph ===
print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()

# === Task 4: Cycle detection in undirected graphs ===
print("--- Cycle Detection ---")
# Create graph with a cycle including D
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C', 'D']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'D')
cycle_graph.add_edge('D', 'A')  # Closing the cycle via D

print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

# Create graph without a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z', 'W']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')
acyclic_graph.add_edge('Z', 'W')
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())