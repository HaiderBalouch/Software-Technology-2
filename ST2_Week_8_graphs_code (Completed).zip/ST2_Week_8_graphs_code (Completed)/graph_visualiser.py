from graph import Graph
import tkinter as tk
import math
import time
import threading

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer - Task 8 Fixed")
        self.geometry('650x700')
        self.graph = graph
        self.canvas = tk.Canvas(self, width=600, height=600, bg='white')
        self.canvas.pack(pady=10)
        
        self.vertex_positions = {}
        self.node_radius = 20
        self.spacing = 180
        self.center = (300, 300)
        self.vertex_circles = {}
        self.edge_lines = {}

        control_frame = tk.Frame(self)
        control_frame.pack()

        # Buttons
        tk.Button(control_frame, text="Run BFS", command=lambda: self.run_traversal("bfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Run DFS", command=lambda: self.run_traversal("dfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Undirected Cycle", command=self.run_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Directed Cycle", command=self.run_directed_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Reset Colors", command=self.reset_colors).pack(side=tk.LEFT, padx=5)

        self.info_label = tk.Label(self, text="Ready", font=("Arial", 10, "bold"))
        self.info_label.pack(pady=5)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        vertices = list(self.graph.graph.keys())
        n = len(vertices)
        if n == 0: return
        angle_gap = 360 / n
        for i, v in enumerate(vertices):
            angle = i * angle_gap
            x = self.center[0] + self.spacing * math.cos(math.radians(angle))
            y = self.center[1] + self.spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
            self.vertex_circles[v] = self.canvas.create_oval(x-20, y-20, x+20, y+20, fill='lightblue', width=2)
            self.canvas.create_text(x, y, text=v, font=("Arial", 12, "bold"))

        for v in vertices:
            for nbr in self.graph.graph[v]:
                x1, y1 = self.vertex_positions[v]
                x2, y2 = self.vertex_positions[nbr]
                # Slight offset to show arrow clearly
                line_id = self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST if self.graph.directed else None, width=2)
                self.edge_lines[(v, nbr)] = line_id
                self.canvas.tag_lower(line_id)

    def reset_colors(self):
        for cid in self.vertex_circles.values(): self.canvas.itemconfig(cid, fill='lightblue')
        for lid in self.edge_lines.values(): self.canvas.itemconfig(lid, fill='black', width=2)
        self.info_label.config(text="Colors Reset")

    def highlight_vertex(self, vertex, color):
        self.canvas.itemconfig(self.vertex_circles[vertex], fill=color)

    def highlight_edge(self, v1, v2, color):
        if (v1, v2) in self.edge_lines:
            self.canvas.itemconfig(self.edge_lines[(v1, v2)], fill=color, width=3)
        elif not self.graph.directed and (v2, v1) in self.edge_lines:
            self.canvas.itemconfig(self.edge_lines[(v2, v1)], fill=color, width=3)

    def run_traversal(self, method):
        def worker():
            self.reset_colors()
            visited = set()
            start_node = next(iter(self.graph.graph))
            if method == "bfs":
                queue = [start_node]
                visited.add(start_node)
                while queue:
                    curr = queue.pop(0)
                    self.highlight_vertex(curr, 'orange')
                    time.sleep(0.5)
                    for nbr in self.graph.graph[curr]:
                        if nbr not in visited:
                            visited.add(nbr)
                            self.highlight_edge(curr, nbr, 'green')
                            queue.append(nbr)
                            time.sleep(0.3)
            else: # DFS
                stack = [start_node]
                while stack:
                    curr = stack.pop()
                    if curr not in visited:
                        visited.add(curr)
                        self.highlight_vertex(curr, 'purple')
                        time.sleep(0.5)
                        for nbr in reversed(self.graph.graph[curr]):
                            if nbr not in visited:
                                self.highlight_edge(curr, nbr, 'blue')
                                stack.append(nbr)
                                time.sleep(0.3)
            self.info_label.config(text=f"{method.upper()} Done")
        threading.Thread(target=worker, daemon=True).start()

    def run_cycle_detection(self):
        """Fixes the Undirected Cycle Detection Button"""
        if self.graph.directed:
            self.info_label.config(text="Switch to Undirected Graph for this test!")
            return

        def worker():
            self.reset_colors()
            visited = set()
            has_cycle = False

            def cycle_dfs(curr, parent):
                visited.add(curr)
                self.highlight_vertex(curr, 'yellow')
                time.sleep(0.5)
                for nbr in self.graph.graph[curr]:
                    if nbr == parent: continue
                    if nbr in visited:
                        # Cycle Found
                        self.highlight_edge(curr, nbr, 'red')
                        self.highlight_vertex(nbr, 'red')
                        self.highlight_vertex(curr, 'red')
                        return True
                    self.highlight_edge(curr, nbr, 'orange')
                    if cycle_dfs(nbr, curr): return True
                return False

            for node in self.graph.graph:
                if node not in visited:
                    if cycle_dfs(node, None):
                        has_cycle = True
                        break
            
            self.info_label.config(text="Cycle Detected!" if has_cycle else "No Cycle Found")

        threading.Thread(target=worker, daemon=True).start()

    def run_directed_cycle_detection(self):
        if not self.graph.directed:
            self.info_label.config(text="Switch to Directed Graph for this test!")
            return

        def worker():
            self.reset_colors()
            visited = set()
            rec_stack = set()
            has_cycle = False

            def dfs(curr):
                visited.add(curr)
                rec_stack.add(curr)
                self.highlight_vertex(curr, 'yellow')
                time.sleep(0.5)
                for nbr in self.graph.graph[curr]:
                    self.highlight_edge(curr, nbr, 'orange')
                    if nbr not in visited:
                        if dfs(nbr): return True
                    elif nbr in rec_stack:
                        self.highlight_edge(curr, nbr, 'red')
                        self.highlight_vertex(nbr, 'red')
                        self.highlight_vertex(curr, 'red')
                        return True
                rec_stack.remove(curr)
                return False

            for node in self.graph.graph:
                if node not in visited:
                    if dfs(node):
                        has_cycle = True
                        break
            self.info_label.config(text="Directed Cycle Found!" if has_cycle else "No Cycle Found")

        threading.Thread(target=worker, daemon=True).start()

# === Testing logic for Task 8 ===
if __name__ == "__main__":
    # To test UNDIRECTED: Set directed=False
    # To test DIRECTED: Set directed=True
    is_directed_test = True # Change this to False to test Undirected button
    
    from graph import Graph
    test_g = Graph(directed=is_directed_test)
    for v in ['A', 'B', 'C', 'D']: test_g.add_vertex(v)
    
    test_g.add_edge('A', 'B')
    test_g.add_edge('B', 'C')
    test_g.add_edge('C', 'A') # Creates the cycle
    test_g.add_edge('C', 'D')

    app = GraphVisualizer(test_g)
    app.mainloop()