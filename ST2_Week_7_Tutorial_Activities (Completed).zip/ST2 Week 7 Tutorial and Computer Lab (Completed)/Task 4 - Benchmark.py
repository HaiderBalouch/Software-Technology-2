import time
import random
import string
import tkinter as tk
from tkinter import ttk
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('Agg')

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        return 0 if not node else self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

def benchmark(n=1000, search_fraction=0.5, delete_count=100, verbose=True):
    names  = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

    bst = BST()
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start

    search_names = random.sample(names, int(n * search_fraction)) + ['notfoundname'] * int(n * (1 - search_fraction))
    start = time.time()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search_time = time.time() - start

    delete_names = random.sample(names, delete_count)
    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start

    avl = AVLTree()
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start

    start = time.time()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search_time = time.time() - start

    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start

    results = {
        'Insertions':      (bst_insert_time, avl_insert_time),
        'Searches':        (bst_search_time, avl_search_time),
        'Deletions':       (bst_delete_time, avl_delete_time),
        'Found In Search': (found_bst, found_avl),
    }

    if verbose:
        print(f"Benchmarking with {n} entries:\n")
        print(f"{'Operation':<12} {'BST Time (sec)':>16} {'AVL Time (sec)':>16}")
        print("-" * 46)
        for op in ['Insertions', 'Searches', 'Deletions']:
            b, a = results[op]
            print(f"{op:<12} {b:>16.6f} {a:>16.6f}")
        print("-" * 46)
        print(f"Contacts found in search:")
        print(f"  BST: {found_bst} / {len(search_names)}")
        print(f"  AVL: {found_avl} / {len(search_names)}")

    return results

def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names  = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

    return bst_times, avl_times

class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL Benchmark")
        master.configure(bg='#1e1e2e')
        master.geometry('700x560')

        label_opts = dict(bg='#1e1e2e', fg='#cdd6f4', font=('Courier', 11))

        tk.Label(master, text="BST vs AVL Tree — Performance Benchmark",
                 bg='#1e1e2e', fg='#89b4fa', font=('Courier', 13, 'bold')).pack(pady=(14, 2))

        size_frame = tk.Frame(master, bg='#1e1e2e')
        size_frame.pack(pady=6)
        tk.Label(size_frame, text="Data size (n):", **label_opts).grid(row=0, column=0, padx=6)
        self.size_var = tk.StringVar(value='1000')
        size_menu = tk.OptionMenu(size_frame, self.size_var, '500', '1000', '2000', '5000', '10000')
        size_menu.config(bg='#313244', fg='#cdd6f4', font=('Courier', 10),
                         activebackground='#45475a', relief='flat')
        size_menu.grid(row=0, column=1, padx=6)

        def btn(bg):
            return dict(bg=bg, fg='#1e1e2e', font=('Courier', 10, 'bold'),
                        relief='flat', padx=12, pady=5, cursor='hand2')

        btn_frame = tk.Frame(master, bg='#1e1e2e')
        btn_frame.pack(pady=6)
        tk.Button(btn_frame, text="Run Benchmark",      command=self.run_benchmark,  **btn('#89b4fa')).grid(row=0, column=0, padx=6)
        tk.Button(btn_frame, text="Plot All Sizes",     command=self.run_plot,        **btn('#cba6f7')).grid(row=0, column=1, padx=6)

        self.result_text = tk.Text(master, height=8, width=72,
                                   bg='#181825', fg='#cdd6f4',
                                   font=('Courier', 10), relief='flat')
        self.result_text.pack(pady=8, padx=16)

        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Custom.Treeview',
                         background='#313244', foreground='#cdd6f4',
                         fieldbackground='#313244', font=('Courier', 10))
        style.configure('Custom.Treeview.Heading',
                         background='#45475a', foreground='#89b4fa',
                         font=('Courier', 10, 'bold'))

        self.tree = ttk.Treeview(master, columns=('Operation', 'BST', 'AVL'),
                                  show='headings', style='Custom.Treeview', height=5)
        self.tree.heading('Operation', text='Operation')
        self.tree.heading('BST',       text='BST Time (s)')
        self.tree.heading('AVL',       text='AVL Time (s)')
        self.tree.column('Operation', width=150, anchor='center')
        self.tree.column('BST',       width=160, anchor='center')
        self.tree.column('AVL',       width=160, anchor='center')
        self.tree.pack(pady=6, padx=16)

        tk.Label(master, text="'Plot All Sizes' saves benchmark_plot.png to the same folder.",
                 bg='#1e1e2e', fg='#585b70', font=('Courier', 9)).pack(pady=(2, 8))

    def run_benchmark(self):
        n = int(self.size_var.get())
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"Running benchmark with n={n}...\n")
        self.master.update()

        results = benchmark(n=n, verbose=False)

        summary = (
            f"{'Operation':<14} {'BST Time (s)':>14} {'AVL Time (s)':>14}\n"
            f"{'-'*44}\n"
        )
        for op in ['Insertions', 'Searches', 'Deletions']:
            b, a = results[op]
            summary += f"{op:<14} {b:>14.6f} {a:>14.6f}\n"
        fb, fa = results['Found In Search']
        summary += f"\nFound in search — BST: {fb}, AVL: {fa} (out of {n})\n"

        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, summary)

        for row in self.tree.get_children():
            self.tree.delete(row)
        for op in ['Insertions', 'Searches', 'Deletions']:
            b, a = results[op]
            self.tree.insert('', tk.END, values=(op, f"{b:.6f}", f"{a:.6f}"))

    def run_plot(self):
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, "Running benchmark across sizes: 100, 500, 1000, 2000, 5000, 10000...\nPlease wait.\n")
        self.master.update()

        sizes = [100, 500, 1000, 2000, 5000, 10000]
        bst_times, avl_times = run_benchmark_for_sizes(sizes, num_search=100, num_delete=50)
        save_plot(sizes, bst_times, avl_times)

        self.result_text.insert(tk.END, "Plot saved as benchmark_plot.png in the same folder.\n")

def save_plot(sizes, bst_times, avl_times, path='benchmark_plot.png'):
    fig, axes = plt.subplots(3, 1, figsize=(10, 9))
    fig.patch.set_facecolor('#1e1e2e')

    ops     = ['insert', 'search', 'delete']
    titles  = ['Insertion Time vs Input Size',
               'Search Time vs Input Size',
               'Deletion Time vs Input Size']

    for ax, op, title in zip(axes, ops, titles):
        ax.set_facecolor('#181825')
        ax.plot(sizes, bst_times[op], 'o-', color='#f38ba8', linewidth=2, label='BST')
        ax.plot(sizes, avl_times[op], 's-', color='#a6e3a1', linewidth=2, label='AVL')
        ax.set_title(title, color='#cdd6f4', fontsize=12)
        ax.set_ylabel('Time (seconds)', color='#cdd6f4')
        ax.tick_params(colors='#cdd6f4')
        for spine in ax.spines.values():
            spine.set_edgecolor('#45475a')
        ax.legend(facecolor='#313244', labelcolor='#cdd6f4')
        ax.grid(True, color='#313244', linestyle='--', alpha=0.5)

    axes[-1].set_xlabel('Number of Nodes', color='#cdd6f4')
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Plot saved to {path}")

if __name__ == "__main__":
    print("=" * 46)
    benchmark(n=1000, verbose=True)
    print()

    # Generate and save the plot
    print("Generating size-comparison plot...")
    sizes = [100, 500, 1000, 2000, 5000, 10000]
    bst_times, avl_times = run_benchmark_for_sizes(sizes)
    save_plot(sizes, bst_times, avl_times)

    root = tk.Tk()
    app = BenchmarkApp(root)
    root.mainloop()