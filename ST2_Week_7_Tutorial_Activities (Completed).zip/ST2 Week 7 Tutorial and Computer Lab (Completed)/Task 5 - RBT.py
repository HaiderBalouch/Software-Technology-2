import time
import random
import string
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

class BSTNode:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class BST:
    def __init__(self): self.root = None

    def insert(self, root, name, phone):
        if root is None: return BSTNode(name, phone)
        if name < root.name: root.left = self.insert(root.left, name, phone)
        elif name > root.name: root.right = self.insert(root.right, name, phone)
        else: root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name: return root
        return self.search(root.left, name) if name < root.name else self.search(root.right, name)

    def find_min(self, root):
        while root.left: root = root.left
        return root

    def delete(self, root, name):
        if root is None: return root
        if name < root.name: root.left = self.delete(root.left, name)
        elif name > root.name: root.right = self.delete(root.right, name)
        else:
            if root.left is None: return root.right
            elif root.right is None: return root.left
            temp = self.find_min(root.right)
            root.name = temp.name; root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def inorder(self, root, res=None):
        if res is None: res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res

class AVLNode:
    def __init__(self, name, phone):
        self.name = name; self.phone = phone
        self.left = None; self.right = None; self.height = 1

class AVLTree:
    def __init__(self): self.root = None

    def height(self, n): return n.height if n else 0
    def get_balance(self, n): return 0 if not n else self.height(n.left) - self.height(n.right)

    def right_rotate(self, z):
        y = z.left; T3 = y.right; y.right = z; z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right; T2 = y.left; y.left = z; z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node: return AVLNode(name, phone)
        if name < node.name: node.left = self.insert(node.left, name, phone)
        elif name > node.name: node.right = self.insert(node.right, name, phone)
        else: node.phone = phone; return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        b = self.get_balance(node)
        if b > 1 and name < node.left.name: return self.right_rotate(node)
        if b < -1 and name > node.right.name: return self.left_rotate(node)
        if b > 1 and name > node.left.name: node.left = self.left_rotate(node.left); return self.right_rotate(node)
        if b < -1 and name < node.right.name: node.right = self.right_rotate(node.right); return self.left_rotate(node)
        return node

    def min_value_node(self, n):
        while n.left: n = n.left
        return n

    def delete(self, root, name):
        if not root: return root
        if name < root.name: root.left = self.delete(root.left, name)
        elif name > root.name: root.right = self.delete(root.right, name)
        else:
            if not root.left: return root.right
            elif not root.right: return root.left
            t = self.min_value_node(root.right)
            root.name = t.name; root.phone = t.phone
            root.right = self.delete(root.right, t.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        b = self.get_balance(root)
        if b > 1 and self.get_balance(root.left) >= 0: return self.right_rotate(root)
        if b > 1 and self.get_balance(root.left) < 0: root.left = self.left_rotate(root.left); return self.right_rotate(root)
        if b < -1 and self.get_balance(root.right) <= 0: return self.left_rotate(root)
        if b < -1 and self.get_balance(root.right) > 0: root.right = self.right_rotate(root.right); return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name: return node
        return self.search(node.left, name) if name < node.name else self.search(node.right, name)

    def inorder(self, root, res=None):
        if res is None: res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res

RED   = True
BLACK = False

class RBNode:
    def __init__(self, name, phone):
        self.name  = name
        self.phone = phone
        self.color = RED
        self.left  = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, None)
        self.NIL.color = BLACK
        self.NIL.left  = None
        self.NIL.right = None
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left   = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right  = x
        x.parent = y

    def insert(self, name, phone):
        existing = self.search(self.root, name)
        if existing != self.NIL:
            existing.phone = phone
            return

        node = RBNode(name, phone)
        node.left   = self.NIL
        node.right  = self.NIL
        node.parent = None

        y = None
        x = self.root
        while x != self.NIL:
            y = x
            if node.name < x.name:
                x = x.left
            else:
                x = x.right

        node.parent = y
        if y is None:
            self.root = node
        elif node.name < y.name:
            y.left = node
        else:
            y.right = node

        if node.parent is None:
            node.color = BLACK
            return
        if node.parent.parent is None:
            return

        self._fix_insert(node)

    def _fix_insert(self, k):
        while k.parent and k.parent.color == RED:
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)
            if k == self.root:
                break
        self.root.color = BLACK

    def search(self, node, name):
        if node == self.NIL or node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def _minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def _transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def delete(self, name):
        z = self.search(self.root, name)
        if z == self.NIL or z is None:
            return
        y = z
        y_original_color = y.color
        if z.left == self.NIL:
            x = z.right
            self._transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self._transplant(z, z.left)
        else:
            y = self._minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self._transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self._transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
        if y_original_color == BLACK:
            self._fix_delete(x)

    def _fix_delete(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                w = x.parent.right
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self.left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == BLACK and w.right.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.right.color == BLACK:
                        w.left.color = BLACK
                        w.color = RED
                        self.right_rotate(w)
                        w = x.parent.right
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.right.color = BLACK
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self.right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == BLACK and w.left.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.left.color == BLACK:
                        w.right.color = BLACK
                        w.color = RED
                        self.left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.left.color = BLACK
                    self.right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

    def inorder(self, node, res=None):
        if res is None: res = []
        if node != self.NIL and node is not None:
            self.inorder(node.left, res)
            res.append((node.name, node.phone))
            self.inorder(node.right, res)
        return res

def run_benchmark(n=1000, verbose=True):
    names  = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    search_names = random.sample(names, n // 2) + ['notfoundname'] * (n // 2)
    delete_names = random.sample(names, min(100, n))

    results = {}
    for label, tree, is_rbt in [('BST', BST(), False), ('AVL', AVLTree(), False), ('RBT', RedBlackTree(), True)]:
        root_ref = None if not is_rbt else None

        t = time.time()
        if is_rbt:
            for i in range(n): tree.insert(names[i], phones[i])
        else:
            root_ref = None
            for i in range(n): root_ref = tree.insert(root_ref, names[i], phones[i])
        ins = time.time() - t

        t = time.time()
        found = 0
        if is_rbt:
            for nm in search_names:
                if tree.search(tree.root, nm) != tree.NIL: found += 1
        else:
            for nm in search_names:
                if tree.search(root_ref, nm): found += 1
        srch = time.time() - t

        t = time.time()
        if is_rbt:
            for nm in delete_names: tree.delete(nm)
        else:
            for nm in delete_names: root_ref = tree.delete(root_ref, nm)
        dlt = time.time() - t

        results[label] = {'insert': ins, 'search': srch, 'delete': dlt, 'found': found}

    if verbose:
        print(f"\nBenchmark Results (n={n}):")
        print(f"{'Operation':<12} {'BST':>12} {'AVL':>12} {'RBT':>12}")
        print('-' * 50)
        for op in ['insert', 'search', 'delete']:
            row = f"{op.capitalize():<12}"
            for lbl in ['BST', 'AVL', 'RBT']:
                row += f" {results[lbl][op]:>12.6f}"
            print(row)
        print('-' * 50)
        print(f"Found (search): BST={results['BST']['found']}, AVL={results['AVL']['found']}, RBT={results['RBT']['found']} / {len(search_names)}")

    return results

def run_sizes(sizes, ns=100, nd=50):
    times = {'BST': {'insert':[],'search':[],'delete':[]},
             'AVL': {'insert':[],'search':[],'delete':[]},
             'RBT': {'insert':[],'search':[],'delete':[]}}

    for n in sizes:
        names  = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        sn = random.sample(names, min(ns, n))
        dn = random.sample(names, min(nd, n))

        bst = BST(); r = None
        t = time.time()
        for i in range(n): r = bst.insert(r, names[i], phones[i])
        times['BST']['insert'].append(time.time()-t)
        t = time.time()
        for nm in sn: bst.search(r, nm)
        times['BST']['search'].append(time.time()-t)
        t = time.time()
        for nm in dn: r = bst.delete(r, nm)
        times['BST']['delete'].append(time.time()-t)

        avl = AVLTree(); r = None
        t = time.time()
        for i in range(n): r = avl.insert(r, names[i], phones[i])
        times['AVL']['insert'].append(time.time()-t)
        t = time.time()
        for nm in sn: avl.search(r, nm)
        times['AVL']['search'].append(time.time()-t)
        t = time.time()
        for nm in dn: r = avl.delete(r, nm)
        times['AVL']['delete'].append(time.time()-t)

        rbt = RedBlackTree()
        t = time.time()
        for i in range(n): rbt.insert(names[i], phones[i])
        times['RBT']['insert'].append(time.time()-t)
        t = time.time()
        for nm in sn: rbt.search(rbt.root, nm)
        times['RBT']['search'].append(time.time()-t)
        t = time.time()
        for nm in dn: rbt.delete(nm)
        times['RBT']['delete'].append(time.time()-t)

    return times

def save_plot(sizes, times, path='rbt_benchmark_plot.png'):
    fig, axes = plt.subplots(3, 1, figsize=(11, 10))
    fig.patch.set_facecolor('#1e1e2e')
    colors = {'BST': '#f38ba8', 'AVL': '#a6e3a1', 'RBT': '#89b4fa'}
    ops    = [('insert', 'Insertion'), ('search', 'Search'), ('delete', 'Deletion')]

    for ax, (op, title) in zip(axes, ops):
        ax.set_facecolor('#181825')
        for lbl, col in colors.items():
            ax.plot(sizes, times[lbl][op], 'o-', color=col, linewidth=2, label=lbl)
        ax.set_title(f'{title} Time vs Input Size', color='#cdd6f4', fontsize=12)
        ax.set_ylabel('Time (seconds)', color='#cdd6f4')
        ax.tick_params(colors='#cdd6f4')
        for spine in ax.spines.values(): spine.set_edgecolor('#45475a')
        ax.legend(facecolor='#313244', labelcolor='#cdd6f4')
        ax.grid(True, color='#313244', linestyle='--', alpha=0.5)

    axes[-1].set_xlabel('Number of Nodes', color='#cdd6f4')
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Plot saved to {path}")

class RBTApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs Red-Black Tree")
        master.configure(bg='#1e1e2e')
        master.geometry('940x780')

        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TNotebook',            background='#1e1e2e', borderwidth=0)
        style.configure('TNotebook.Tab',        background='#313244', foreground='#cdd6f4',
                         font=('Courier', 10, 'bold'), padding=[12, 4])
        style.map('TNotebook.Tab',              background=[('selected', '#89b4fa')],
                                                foreground=[('selected', '#1e1e2e')])
        style.configure('Custom.Treeview',      background='#313244', foreground='#cdd6f4',
                         fieldbackground='#313244', font=('Courier', 10))
        style.configure('Custom.Treeview.Heading', background='#45475a', foreground='#89b4fa',
                         font=('Courier', 10, 'bold'))

        nb = ttk.Notebook(master)
        nb.pack(fill='both', expand=True, padx=10, pady=10)

        self.dir_tab = tk.Frame(nb, bg='#1e1e2e')
        nb.add(self.dir_tab, text='RBT Contact Directory')
        self._build_directory_tab()

        self.bench_tab = tk.Frame(nb, bg='#1e1e2e')
        nb.add(self.bench_tab, text='Benchmark BST vs AVL vs RBT')
        self._build_benchmark_tab()

    def _build_directory_tab(self):
        self.rbt = RedBlackTree()
        f = self.dir_tab

        label_opts = dict(bg='#1e1e2e', fg='#cdd6f4', font=('Courier', 11))
        entry_opts  = dict(bg='#313244', fg='#cdd6f4', insertbackground='#cdd6f4',
                           relief='flat', font=('Courier', 11), width=22)

        inp = tk.Frame(f, bg='#1e1e2e')
        inp.pack(pady=10)
        tk.Label(inp, text="Name:",  **label_opts).grid(row=0, column=0, padx=6, sticky='e')
        self.name_entry = tk.Entry(inp, **entry_opts)
        self.name_entry.grid(row=0, column=1, padx=6, pady=3)
        tk.Label(inp, text="Phone:", **label_opts).grid(row=1, column=0, padx=6, sticky='e')
        self.phone_entry = tk.Entry(inp, **entry_opts)
        self.phone_entry.grid(row=1, column=1, padx=6, pady=3)

        def btn(bg):
            return dict(bg=bg, fg='#1e1e2e', font=('Courier', 10, 'bold'),
                        relief='flat', padx=10, pady=5, cursor='hand2')

        bf = tk.Frame(f, bg='#1e1e2e')
        bf.pack(pady=4)
        tk.Button(bf, text="Insert",    command=self._dir_insert,   **btn('#89b4fa')).grid(row=0, column=0, padx=4)
        tk.Button(bf, text="Search",    command=self._dir_search,   **btn('#a6e3a1')).grid(row=0, column=1, padx=4)
        tk.Button(bf, text="Delete",    command=self._dir_delete,   **btn('#f38ba8')).grid(row=0, column=2, padx=4)
        tk.Button(bf, text="Show All",  command=self._dir_show_all, **btn('#f9e2af')).grid(row=0, column=3, padx=4)

        self.dir_output = tk.Text(f, height=8, width=75,
                                  bg='#181825', fg='#cdd6f4',
                                  font=('Courier', 10), relief='flat')
        self.dir_output.pack(pady=6, padx=12)

        cf = tk.Frame(f, bg='#313244')
        cf.pack(fill='both', expand=True, padx=12, pady=(0, 10))
        tk.Label(cf, text="Red-Black Tree Visualiser  (R=red node, B=black node)",
                 bg='#313244', fg='#89b4fa', font=('Courier', 10, 'bold')).pack(anchor='w', padx=8, pady=2)
        self.dir_canvas = tk.Canvas(cf, bg='#1e1e2e', highlightthickness=0)
        self.dir_canvas.pack(fill='both', expand=True)

    def _dir_insert(self):
        name  = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return
        self.rbt.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated: {name}")
        self.name_entry.delete(0, tk.END); self.phone_entry.delete(0, tk.END)
        self._dir_show_all(); self._draw_rbt()

    def _dir_search(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a Name to search.")
            return
        node = self.rbt.search(self.rbt.root, name)
        self.dir_output.delete(1.0, tk.END)
        if node != self.rbt.NIL and node is not None:
            self.dir_output.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\nColour: {'Red' if node.color == RED else 'Black'}\n")
        else:
            self.dir_output.insert(tk.END, "Contact not found.\n")

    def _dir_delete(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a Name to delete.")
            return
        self.rbt.delete(name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.name_entry.delete(0, tk.END); self.phone_entry.delete(0, tk.END)
        self._dir_show_all(); self._draw_rbt()

    def _dir_show_all(self):
        self.dir_output.delete(1.0, tk.END)
        contacts = self.rbt.inorder(self.rbt.root)
        if not contacts:
            self.dir_output.insert(tk.END, "No contacts found.\n")
        else:
            for n, p in contacts:
                self.dir_output.insert(tk.END, f"Name: {n}, Phone: {p}\n")

    def _draw_rbt(self):
        self.dir_canvas.update()
        self.dir_canvas.delete("all")
        if self.rbt.root == self.rbt.NIL:
            return
        w = self.dir_canvas.winfo_width()
        self._draw_rbt_node(self.rbt.root, w // 2, 30, w // 4, 65, 22)

    def _draw_rbt_node(self, node, x, y, x_offset, level_gap, radius):
        if node == self.rbt.NIL or node is None:
            return
        fill = '#f38ba8' if node.color == RED else '#45475a'
        text_col = '#1e1e2e' if node.color == RED else '#cdd6f4'

        if node.left != self.rbt.NIL:
            xl, yl = x - x_offset, y + level_gap
            self.dir_canvas.create_line(x, y, xl, yl, fill='#585b70', width=2)
            self._draw_rbt_node(node.left,  xl, yl, max(x_offset // 2, 22), level_gap, radius)

        if node.right != self.rbt.NIL:
            xr, yr = x + x_offset, y + level_gap
            self.dir_canvas.create_line(x, y, xr, yr, fill='#585b70', width=2)
            self._draw_rbt_node(node.right, xr, yr, max(x_offset // 2, 22), level_gap, radius)

        self.dir_canvas.create_oval(x-radius, y-radius, x+radius, y+radius,
                                    fill=fill, outline='#cdd6f4', width=1)
        display = node.name if len(node.name) <= 7 else node.name[:6] + '…'
        self.dir_canvas.create_text(x, y-4, text=display, fill=text_col, font=('Courier', 8, 'bold'))
        self.dir_canvas.create_text(x, y+7, text='R' if node.color==RED else 'B',
                                    fill=text_col, font=('Courier', 7))

    def _build_benchmark_tab(self):
        f = self.bench_tab

        tk.Label(f, text="BST vs AVL vs Red-Black Tree — Benchmark",
                 bg='#1e1e2e', fg='#89b4fa', font=('Courier', 13, 'bold')).pack(pady=(14, 4))

        sf = tk.Frame(f, bg='#1e1e2e')
        sf.pack(pady=4)
        tk.Label(sf, text="Data size (n):", bg='#1e1e2e', fg='#cdd6f4',
                 font=('Courier', 11)).grid(row=0, column=0, padx=6)
        self.bench_size = tk.StringVar(value='1000')
        om = tk.OptionMenu(sf, self.bench_size, '500', '1000', '2000', '5000', '10000')
        om.config(bg='#313244', fg='#cdd6f4', font=('Courier', 10),
                  activebackground='#45475a', relief='flat')
        om.grid(row=0, column=1, padx=6)

        def btn(bg):
            return dict(bg=bg, fg='#1e1e2e', font=('Courier', 10, 'bold'),
                        relief='flat', padx=12, pady=5, cursor='hand2')

        bf = tk.Frame(f, bg='#1e1e2e')
        bf.pack(pady=6)
        tk.Button(bf, text="Run Benchmark", command=self._run_bench, **btn('#89b4fa')).grid(row=0, column=0, padx=6)
        tk.Button(bf, text="Plot All Sizes", command=self._run_plot,  **btn('#cba6f7')).grid(row=0, column=1, padx=6)

        self.bench_output = tk.Text(f, height=7, width=78,
                                    bg='#181825', fg='#cdd6f4',
                                    font=('Courier', 10), relief='flat')
        self.bench_output.pack(pady=6, padx=12)

        self.bench_tree = ttk.Treeview(f, columns=('op','bst','avl','rbt'),
                                        show='headings', style='Custom.Treeview', height=5)
        for col, hdr, w in [('op','Operation',130),('bst','BST (s)',160),('avl','AVL (s)',160),('rbt','RBT (s)',160)]:
            self.bench_tree.heading(col, text=hdr)
            self.bench_tree.column(col, width=w, anchor='center')
        self.bench_tree.pack(pady=6, padx=12)

        tk.Label(f, text="'Plot All Sizes' saves rbt_benchmark_plot.png to the same folder.",
                 bg='#1e1e2e', fg='#585b70', font=('Courier', 9)).pack(pady=(2, 8))

    def _run_bench(self):
        n = int(self.bench_size.get())
        self.bench_output.delete(1.0, tk.END)
        self.bench_output.insert(tk.END, f"Running benchmark with n={n}...\n")
        self.master.update()

        results = run_benchmark(n=n, verbose=False)

        lines = f"{'Operation':<12} {'BST (s)':>12} {'AVL (s)':>12} {'RBT (s)':>12}\n" + '-'*50 + '\n'
        for op in ['insert', 'search', 'delete']:
            lines += f"{op.capitalize():<12} {results['BST'][op]:>12.6f} {results['AVL'][op]:>12.6f} {results['RBT'][op]:>12.6f}\n"
        lines += f"\nFound: BST={results['BST']['found']}, AVL={results['AVL']['found']}, RBT={results['RBT']['found']} / {n}\n"

        self.bench_output.delete(1.0, tk.END)
        self.bench_output.insert(tk.END, lines)

        for row in self.bench_tree.get_children(): self.bench_tree.delete(row)
        for op in ['insert', 'search', 'delete']:
            self.bench_tree.insert('', tk.END, values=(
                op.capitalize(),
                f"{results['BST'][op]:.6f}",
                f"{results['AVL'][op]:.6f}",
                f"{results['RBT'][op]:.6f}"
            ))

    def _run_plot(self):
        self.bench_output.delete(1.0, tk.END)
        self.bench_output.insert(tk.END, "Running across sizes: 100, 500, 1000, 2000, 5000, 10000...\nPlease wait.\n")
        self.master.update()
        sizes = [100, 500, 1000, 2000, 5000, 10000]
        times = run_sizes(sizes)
        save_plot(sizes, times)
        self.bench_output.insert(tk.END, "Done! Plot saved as rbt_benchmark_plot.png\n")

if __name__ == '__main__':
    import sys
    sys.setrecursionlimit(50000)

    print("=" * 50)
    run_benchmark(n=1000, verbose=True)
    print()

    print("Generating size-comparison plot...")
    sizes = [100, 500, 1000, 2000, 5000, 10000]
    times = run_sizes(sizes)
    save_plot(sizes, times)

    root = tk.Tk()
    app = RBTApp(root)
    root.mainloop()