import tkinter as tk
from tkinter import messagebox
import time

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)

        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)

        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if root is None:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)


        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res

class AVLApp:
    def __init__(self, master):
        self.tree = AVLTree()
        self.master = master
        master.title("AVL Contact Directory")
        master.configure(bg='#1e1e2e')
        master.geometry('920x720')
        master.resizable(True, True)

        frame = tk.Frame(master, bg='#1e1e2e')
        frame.pack(pady=12)

        label_opts = dict(bg='#1e1e2e', fg='#cdd6f4', font=('Courier', 11))
        entry_opts  = dict(bg='#313244', fg='#cdd6f4', insertbackground='#cdd6f4',
                           relief='flat', font=('Courier', 11), width=24)

        tk.Label(frame, text="Name:",  **label_opts).grid(row=0, column=0, padx=6, sticky='e')
        self.name_entry = tk.Entry(frame, **entry_opts)
        self.name_entry.grid(row=0, column=1, padx=6, pady=3)

        tk.Label(frame, text="Phone:", **label_opts).grid(row=1, column=0, padx=6, sticky='e')
        self.phone_entry = tk.Entry(frame, **entry_opts)
        self.phone_entry.grid(row=1, column=1, padx=6, pady=3)

        def btn(bg):
            return dict(bg=bg, fg='#1e1e2e', font=('Courier', 10, 'bold'),
                        relief='flat', padx=10, pady=5, cursor='hand2')

        btn_frame = tk.Frame(master, bg='#1e1e2e')
        btn_frame.pack(pady=6)

        tk.Button(btn_frame, text="Insert Contact",   command=self.insert_contact,  **btn('#89b4fa')).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Search Contact",   command=self.search_contact,  **btn('#a6e3a1')).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Delete Contact",   command=self.delete_contact,  **btn('#f38ba8')).grid(row=0, column=2, padx=5)
        tk.Button(btn_frame, text="Show All Contacts",command=self.show_all,        **btn('#f9e2af')).grid(row=0, column=3, padx=5)

        self.output_text = tk.Text(master, height=9, width=80,
                                   bg='#181825', fg='#cdd6f4',
                                   font=('Courier', 10), relief='flat',
                                   insertbackground='#cdd6f4')
        self.output_text.pack(pady=8, padx=16)

        canvas_frame = tk.Frame(master, bg='#313244', bd=1, relief='flat')
        canvas_frame.pack(fill='both', expand=True, padx=16, pady=(0, 12))

        tk.Label(canvas_frame, text="AVL Tree Visualiser  (balance factor shown in brackets)",
                 bg='#313244', fg='#a6e3a1', font=('Courier', 10, 'bold')).pack(anchor='w', padx=8, pady=2)

        self.canvas = tk.Canvas(canvas_frame, bg='#1e1e2e', highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)

    def insert_contact(self):
        name  = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return
        self.tree.root = self.tree.insert(self.tree.root, name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to search.")
            return
        node = self.tree.search(self.tree.root, name)
        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to delete.")
            return
        self.tree.root = self.tree.delete(self.tree.root, name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder(self.tree.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for n, p in contacts:
                self.output_text.insert(tk.END, f"Name: {n}, Phone: {p}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.update()
        self.canvas.delete("all")
        if not self.tree.root:
            return
        w = self.canvas.winfo_width()
        self._draw_node(self.tree.root, w // 2, 30, w // 4, 70, 22)

    def _draw_node(self, node, x, y, x_offset, level_gap, radius):
        if not node:
            return

        balance = self.tree.get_balance(node)

        if balance == 0:
            fill = '#a6e3a1'
        elif abs(balance) == 1:
            fill = '#f9e2af'
        else:
            fill = '#f38ba8'

        if node.left:
            xl, yl = x - x_offset, y + level_gap
            self.canvas.create_line(x, y, xl, yl, fill='#585b70', width=2)
            self._draw_node(node.left,  xl, yl, max(x_offset // 2, 22), level_gap, radius)

        if node.right:
            xr, yr = x + x_offset, y + level_gap
            self.canvas.create_line(x, y, xr, yr, fill='#585b70', width=2)
            self._draw_node(node.right, xr, yr, max(x_offset // 2, 22), level_gap, radius)

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                fill=fill, outline='#cdd6f4', width=1)

        display = node.name if len(node.name) <= 7 else node.name[:6] + '…'
        self.canvas.create_text(x, y - 4, text=display, fill='#1e1e2e',
                                font=('Courier', 8, 'bold'))
        self.canvas.create_text(x, y + 7, text=f'[{balance:+d}]', fill='#1e1e2e',
                                font=('Courier', 7))


if __name__ == "__main__":
    root = tk.Tk()
    app = AVLApp(root)
    root.mainloop()