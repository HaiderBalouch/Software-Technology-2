import tkinter as tk
from tkinter import messagebox
import time
import random
import string

class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class ContactDirectory:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Contact(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def inorder(self, root, result=None):
        if result is None:
            result = []
        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)
        return result

class BSTVisualizerApp:
    def __init__(self, root):
        self.directory = ContactDirectory()
        self.root = root
        self.root.title("Contact Directory BST")
        self.root.configure(bg='#1e1e2e')
        self.root.geometry("900x700")
        self.root.resizable(True, True)

        frame = tk.Frame(root, bg='#1e1e2e')
        frame.pack(pady=12)

        label_opts = dict(bg='#1e1e2e', fg='#cdd6f4', font=('Courier', 11))
        entry_opts = dict(bg='#313244', fg='#cdd6f4', insertbackground='#cdd6f4',
                          relief='flat', font=('Courier', 11), width=24)

        tk.Label(frame, text="Name:", **label_opts).grid(row=0, column=0, padx=6, sticky='e')
        self.name_entry = tk.Entry(frame, **entry_opts)
        self.name_entry.grid(row=0, column=1, padx=6, pady=3)

        tk.Label(frame, text="Phone:", **label_opts).grid(row=1, column=0, padx=6, sticky='e')
        self.phone_entry = tk.Entry(frame, **entry_opts)
        self.phone_entry.grid(row=1, column=1, padx=6, pady=3)

        btn_frame = tk.Frame(root, bg='#1e1e2e')
        btn_frame.pack(pady=6)

        def btn(bg):
            return dict(bg=bg, fg='#1e1e2e', font=('Courier', 10, 'bold'),
                        relief='flat', padx=10, pady=5, cursor='hand2')
        btn_style     = btn('#89b4fa')
        btn_style_grn = btn('#a6e3a1')
        btn_style_red = btn('#f38ba8')
        btn_style_ylw = btn('#f9e2af')
        btn_style_ppl = btn('#cba6f7')

        tk.Button(btn_frame, text="Insert Contact",  command=self.insert_contact,  **btn_style    ).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Search Contact",  command=self.search_contact,  **btn_style_grn).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Delete Contact",  command=self.delete_contact,  **btn_style_red).grid(row=0, column=2, padx=5)
        tk.Button(btn_frame, text="Show All Contacts", command=self.show_all,      **btn_style_ylw).grid(row=0, column=3, padx=5)
        tk.Button(btn_frame, text="Run Benchmark",   command=self.benchmark,       **btn_style_ppl).grid(row=0, column=4, padx=5)

        self.output_text = tk.Text(root, height=9, width=80,
                                   bg='#181825', fg='#cdd6f4',
                                   font=('Courier', 10), relief='flat',
                                   insertbackground='#cdd6f4')
        self.output_text.pack(pady=8, padx=16)

        # ── Canvas for tree visualisation ──
        canvas_frame = tk.Frame(root, bg='#313244', bd=1, relief='flat')
        canvas_frame.pack(fill='both', expand=True, padx=16, pady=(0, 12))

        tk.Label(canvas_frame, text="BST Visualiser", bg='#313244',
                 fg='#89b4fa', font=('Courier', 10, 'bold')).pack(anchor='w', padx=8, pady=2)

        self.canvas = tk.Canvas(canvas_frame, bg='#1e1e2e', highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)

    def insert_contact(self):
        name  = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both name and phone number.")
            return
        self.directory.root = self.directory.insert(self.directory.root, name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a name to search.")
            return
        node = self.directory.search(self.directory.root, name)
        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a name to delete.")
            return
        self.directory.root = self.directory.delete(self.directory.root, name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.directory.inorder(self.directory.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for name, phone in contacts:
                self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.update()
        self.canvas.delete("all")
        if not self.directory.root:
            return
        w = self.canvas.winfo_width()
        start_x     = w // 2
        start_y     = 30
        level_gap   = 70
        node_radius = 22
        self._draw_node(self.directory.root, start_x, start_y,
                        w // 4, level_gap, node_radius)

    def _draw_node(self, node, x, y, x_offset, level_gap, radius):
        if node is None:
            return
        if node.left:
            xl, yl = x - x_offset, y + level_gap
            self.canvas.create_line(x, y, xl, yl, fill='#585b70', width=2)
            self._draw_node(node.left, xl, yl, max(x_offset // 2, 20), level_gap, radius)
        if node.right:
            xr, yr = x + x_offset, y + level_gap
            self.canvas.create_line(x, y, xr, yr, fill='#585b70', width=2)
            self._draw_node(node.right, xr, yr, max(x_offset // 2, 20), level_gap, radius)
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                fill='#89b4fa', outline='#cdd6f4', width=1)
        display_name = node.name if len(node.name) <= 8 else node.name[:7] + '…'
        self.canvas.create_text(x, y, text=display_name, fill='#1e1e2e',
                                font=('Courier', 8, 'bold'))

    def benchmark(self):
        self.directory.root = None
        N = 1000
        names  = [''.join(random.choices(string.ascii_lowercase, k=7)) for _ in range(N)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(N)]

        start = time.time()
        for i in range(N):
            self.directory.root = self.directory.insert(self.directory.root, names[i], phones[i])
        insert_time = time.time() - start

        search_names = random.sample(names, N // 2) + ['notfoundname'] * (N // 2)
        start = time.time()
        found_count = sum(1 for n in search_names if self.directory.search(self.directory.root, n))
        search_time = time.time() - start

        delete_names = random.sample(names, 100)
        start = time.time()
        for n in delete_names:
            self.directory.root = self.directory.delete(self.directory.root, n)
        delete_time = time.time() - start

        result_text = (
            f"Benchmark Results (N={N}):\n"
            f"Insertion time: {insert_time:.4f} seconds\n"
            f"Search time (for {len(search_names)} queries, found {found_count}): {search_time:.4f} seconds\n"
            f"Deletion time (for 100 deletions): {delete_time:.4f} seconds\n"
        )
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, result_text)
        self.draw_tree()


if __name__ == "__main__":
    root = tk.Tk()
    app = BSTVisualizerApp(root)
    root.mainloop()