import tkinter as tk
from tkinter import messagebox
from collections import deque

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 10
CANVAS_WIDTH = 700
CANVAS_HEIGHT = 200


class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = deque()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Enqueue Value:").grid(row=0, column=0)
        self.enqueue_entry = tk.Entry(control_frame, width=10)
        self.enqueue_entry.grid(row=0, column=1)

        enqueue_btn = tk.Button(control_frame, text="Enqueue", command=self.enqueue_value)
        enqueue_btn.grid(row=0, column=2, padx=5)

        dequeue_btn = tk.Button(control_frame, text="Dequeue", command=self.dequeue_value)
        dequeue_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data, highlight=False):
        fill = "lightyellow" if highlight else "lightgreen"
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill=fill, outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2,
            text=str(data), font=("Arial", 16)
        )

    def draw_queue(self, highlight_front=False):
        self.canvas.delete("all")
        items = list(self.queue)
        total = len(items)
        if total == 0:
            self.canvas.create_text(
                CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2,
                text="Queue is empty", font=("Arial", 14), fill="grey"
            )
            return

        # Centre the row of nodes horizontally
        total_w = total * NODE_WIDTH + (total - 1) * HORIZONTAL_GAP
        x = (CANVAS_WIDTH - total_w) // 2
        y = (CANVAS_HEIGHT - NODE_HEIGHT) // 2

        for i, val in enumerate(items):
            hl = (highlight_front and i == 0)
            self.draw_node(x, y, val, highlight=hl)

            # Arrow between nodes
            if i < total - 1:
                ax1 = x + NODE_WIDTH
                ay  = y + NODE_HEIGHT // 2
                ax2 = ax1 + HORIZONTAL_GAP
                self.canvas.create_line(ax1, ay, ax2, ay, arrow=tk.LAST, width=2)

            x += NODE_WIDTH + HORIZONTAL_GAP

        # Labels: FRONT (left) and REAR (right)
        lx = (CANVAS_WIDTH - total_w) // 2
        rx = lx + total_w - NODE_WIDTH
        label_y = y + NODE_HEIGHT + 18
        self.canvas.create_text(lx + NODE_WIDTH // 2, label_y,
                                text="FRONT", font=("Arial", 11), fill="red")
        self.canvas.create_text(rx + NODE_WIDTH // 2, label_y,
                                text="REAR",  font=("Arial", 11), fill="green")

    def enqueue_value(self):
        try:
            val = int(self.enqueue_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value.")
            return
        self.queue.append(val)          # add to rear
        self.enqueue_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {val} at rear  (FIFO)")
        self.draw_queue()

    def dequeue_value(self):
        if not self.queue:
            messagebox.showinfo("Empty Queue", "Queue is empty. Nothing to dequeue.")
            return
        # Flash the front node before removing
        self.draw_queue(highlight_front=True)
        val = self.queue.popleft()      # remove from front
        self.root.after(400, lambda: self._finish_dequeue(val))

    def _finish_dequeue(self, val):
        self.status_label.config(text=f"Dequeued {val} from front  (FIFO)")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    root.mainloop()
